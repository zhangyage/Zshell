#!/bin/bash
read -p "请输入你要删除的项目名称：" user_1
read -p "确认项目名称：" user_2
if [ -z $user_1 ]
    then
	echo "您什么也没有输入"
	exit
elif [ -z $user_2 ]
    then
	echo "您什么也没有输入"
	exit
else
    echo "    "
fi

if [ $user_1 = $user_2 ]
    then
	userdel -r $user_1
	\rm -rf /home/sftp/$user_1
	\rm -rf /usr/local/nginx/html/upload//$user_1
else
	echo "两次名称不一致，请重新运行此脚本"
fi

