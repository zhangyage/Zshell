#!/bin/bash
read -p "请输入用户名：" user
read -p "请输入密码：" pass
if [ -z $user ]
    then
	echo "用户名不允许为空"
	exit
elif [ -z $pass ]
    then
	echo "密码不允许为空"
	exit
else
	echo " "
fi
user_1=`cat /etc/passwd|grep $user`
if [ -z "$user_1" ]
    then
	echo " "
else
	echo "有同名用户或项目"
	exit
fi
mkdir -p /home/sftp/$user/upload
useradd -s /bin/false -g sftpusers -d /home/sftp/$user/ $user &> /tmp/user.list
read -p "请输入你要拷贝的项目名：" olduser_1
if [ -z "$olduser_1" ]
    then
	echo "不进行拷贝"
else
    olduser_2=`ls /home/sftp/|grep $olduser_1`
    if [ -z "$olduser_2" ]
        then
	    echo "没有你说的那个项目"
    else
        cp -r /home/sftp/$olduser_2/upload/* /home/sftp/$user/upload/
    fi
fi
\cp -r /home/sftp/moban/userPhoto/ /home/sftp/$user/upload/
chown -R $user:sftpusers /home/sftp/$user/upload/
echo "$pass" | passwd --stdin $user
cd /usr/local/nginx/html/upload/
ln -s /home/sftp/$user/upload $user
#setfacl -R -m u:$user:rwx /home/tomcat-file/webapps/upload/$user
#setfacl -R -m g:virtual:rwx /home/tomcat-file/webapps/upload/$user
#setfacl -d --set u:$user:rwx /home/tomcat-file/webapps/upload/$user
#setfacl -d --set g:virtual:rwx /home/tomcat-file/webapps/upload/$user
#useradd -d
