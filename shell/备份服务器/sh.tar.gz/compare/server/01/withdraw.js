if(userId == "null"){
	window.location.href = path + "/common/m-login.html";
}
$(function() {
	//返回上一页
	$(".back").click(function(){
		history.go(-1);
	});
	//判断底部去个人中心按钮
	if(userId == "null"){ //未登录
		$("#bottom2Center").click(function(){
			window.location.href = path + "/common/m-login.html";
		});
	}else{
		$("#bottom2Center").attr("href", path + "/common/m-myCenter.html");
	}
	$("#verifyCode").blur(function(){
		if($(this).val()){
			$(this).parent().children(".inputf").hide();
		}
	});
//	bindCard();
	getUserBank();//查询已经绑定的银行卡
	getUserdAmt();//查询用户可用余额
	$("#amtInput").blur(withdrawInput);
	$("#verifyCode").blur(function(){
		if($(this).val()){
			$(this).parent().children(".inputf").hide();
		}
	});
	$("#getCodeBtn").click(getPhoneCode);
	$("#withdrawBtn").click(withDraw);
	$("#unbindCard").click(unbindCard);
	$("#bindCard").click(bindCard)
});

function unbindCard(){
	$.ajax({
		url: path + "/yeepay/unbindBankcard/unbindBankCard.html",
		type: "post",
		dataType: "json",
		success: function(data){
			if(!data["success"]){
				AlertDialog.mtip("解绑失败");
				return false;
			}else{
				AlertDialog.mtip("解绑成功",function(){
					window.location.href = window.location.href;
				});
				setTimeout(function(){
					window.location.href = window.location.href;					
				},2000);
			}
		},
		error: function(request){
			console.log("获取已绑定银行信息异常");
		}
	});
}
//查询已经绑定的银行卡信息
function getUserBank(){
	$.ajax({
		url: path + "/withdraw/getUserBankList.html",
		type: "post",
		dataType: "json",
		success: function(data){
			if(!data["success"]){
				$("#unbindCard").hide();
				$("#unbindingMessage").hide();
				return false;
			}
			data = data["msg"];
			if(data.length == 0){
				$("#unbindCard").hide();
				$("#bindCard").show();
				$("#unbindingMessage").hide();
				return false;
			}
			if(data[0]["state"]=="unbinding" || data[0]["state"]=="bind"){
				$("#bankLogo").attr("src",path+"/images/bank/S_"+data[0]["bankNo"]+".png");//银行小logo
				$("#bankNum").text(data[0]["bankAccount"]);//银行卡号
			}
			if(data[0]["state"]=="bind"){
				$("#unbindCard").show();
				$("#bindCard").hide();
			}
			$("#unbindingMessage").hide();
			if(data[0]["state"]=="unbinding"){
				$("#unbindCard").hide();
				$("#bindCard").hide();
				$("#unbindingMessage").show();
			}
		},
		error: function(request){
			console.log("获取已绑定银行信息异常");
		}
	});
}
//查询用户可用余额值
function getUserdAmt(){
	$.ajax({
		url: path + "/bill/getUserBalance.html",
		type: "post",
		dataType: "json",
		success: function(data){
			if(!data["success"]){
				return false;
			}
			$("#canUserdAmt").text(data["msg"].toFixed(2));
		},
		error: function(request){
			conosle.log("获取用户可用余额值异常");
		}
	});
}
//取现金额输入框事件
function withdrawInput(){
	//应该输入数字并且小于等于 可用金额
	var val = $("#amtInput").val();
	if(!val){
		AlertDialog.show("请输入提现金额","amtInput",10,100);
		return false;
	}
	if(Number(val) == 0){
		AlertDialog.show("提现金额不能为0","amtInput",10,100);
		return false;
	}
	if(Number(val) < 0){
		AlertDialog.show("提现金额不能为负数","amtInput",10,100);
		return;
	}
	if(Number($("#canUserdAmt").text())-2 <=0){
		AlertDialog.show("可用余额不足以支付手续费 无法提现","amtInput",10,100);
	}else if(isNaN(val) || Number(val)+2 > Number($("#canUserdAmt").text())){
		var maxInput = Number($("#canUserdAmt").text()) -2;
		AlertDialog.show("输入金额 不能大于"+maxInput,"amtInput",10,100);
		return false;
	}else if(!isNaN(val) && Number(val) <= Number($("#canUserdAmt").text())){
		AlertDialog.hide();
		return true;
	}
}

//获取手机验证码
function getPhoneCode(){
	if(withdrawInput()){
		$.ajax({
			url: path + "/verifycode/sendUserVerifyCode.html",
			type: "post",
			dataType: "json",
			data: {"codeType": "withdraw_remind"},
			success: function(data){
				if(!data["success"]){
					$("#getCodeBtn").parent().children(".inputf").text(data["msg"]).show();
				}else{
					$("#getCodeBtn").unbind("click").css({"color":"#434343","cursor":"default"}).text("60 秒后可重发");
					countDown(60, "getCodeBtn", overFn);
				}
			},
			error: function(request){
				conosle.log("获取用户可用余额值异常");
			}
		});
	}
}
function overFn(){
	$("#getCodeBtn").text("获取验证码").css({"cursor":"pointer"});
	$("#getCodeBtn").click(getPhoneCode);
}
//取现
function withDraw(){
	if(withdrawInput()){
		if(Number($("#canUserdAmt").html()) < Number($('#amtInput').val())+2){
			AlertDialog.tip("提现金额应小于等于可用余额减去提现手续费");
			return false;
		}
		if($("#verifyCode").val()){
			//提现前验证
			$.ajax({
				url: path + "/withdraw/checkWithdraw.html",
				type: "post",
				dataType: "json",
				async: false,
				data: {
					"amt": $("#amtInput").val(),
					"fee": "2",
					"verifyCode": $("#verifyCode").val()
				},
				success: function(data){
					if(data["success"]){
						$("#withdrawBtn").css("background", "#ccc").unbind("click");
						 $("#withBtn").click();
					}else{
						if(data["msg"]){
							if(data["msg"].indexOf("验证码")>-1){
								AlertDialog.show(data["msg"],"verifyCode",10,100);
								return false;
							}
							AlertDialog.mtip(data["msg"]);
						}else{
							AlertDialog.mtip("取现异常，请联系客服");
						}
					}
				},
				error: function(request){
					console.log("获取提现信息异常");
				}
			});
		}else{
			AlertDialog.show("请输入验证码","verifyCode",0,30);
			return false;
		}
	}else{
//		AlertDialog.show("请输入小于或等于可用余额的数字","amtInput",0,155);
		return false;
	}
}

//绑定银行卡前验证
function bindCard(){
	$.ajax({
		url: path + "/third/bankcard/checkBeforeBindBank.html",
		type: "post",
		dataType: "json",
		success: function(data){
			if(data["success"]){
				$("#bindCard").attr("href", path + "/yeepay/bankcard/createBankCardWap.html?" + new Date().getTime());
			}else{
				$("#bindCard").click(function(){
					AlertDialog.tip(data["msg"]);
				});
			}
		},
		error: function(request){
			console.log("绑卡异常");
		}
	});
}