if(userId == "null"){
	window.location.href = path + "/common/login.html";
}

$(function(){
	//禁止输入空格
	$("input").keyup(function(){
		$(this).val($(this).val().replace(/\s/g,''));
	});
	
//	bindCard();
	getUserBank();//查询已经绑定的银行卡
	getUserdAmt();//查询用户可用余额
	$("#amtInput").blur(withdrawInput);
	var reg = /^(?!00)\d+(\.\d{1,2})?$/;
	$("#amtInput").keyup(function(){
		if(/([0-9]+\.[0-9]{3})[0-9]*/.test($(this).val())){
			$(this).val($(this).val().substring(0,$(this).val().length-1));
		}
	});
	$("#verifyCode").blur(function(){
		if($(this).val()){
			$(this).parent().children(".inputf").hide();
		}
	});
	$("#amtInput").on("keydown", function(event){
		var e = event || window.event || arguments.callee.caller.arguments[0];
		if(e && e.keyCode==13){
			return false;
		}
	});
	$("#verifyCode").on("keydown", function(event){
		var e = event || window.event || arguments.callee.caller.arguments[0];
		if(e && e.keyCode==13){
			return false;
		}
	});
	$("#getCodeBtn").click(getPhoneCode);
	$("#withdrawBtn").click(withDraw);
	$("#unbindCard").click(unbindCard);
	
});

function unbindCard(){
	$.ajax({
		url: path + "/yeepay/unbindBankcard/unbindBankCard.html",
		type: "post",
		dataType: "json",
		success: function(data){
			if(!data["success"]){
				AlertDialog.tip("解绑失败");
				return false;
			}else{
				AlertDialog.tip("解绑成功");
				setTimeout(function(){
					window.location.href = window.location.href;					
				},2000);
			}
		},
		error: function(request){
			console.log("获取已绑定银行信息异常");
		}
	});
}
//查询已经绑定的银行卡信息
/*function getUserBank(){
	$.ajax({
		url: path + "/withdraw/getUserBankList.html",
		type: "post",
		dataType: "json",
		success: function(data){
			if(!data["success"]){
				$("#unbindCard").hide();
				$("#unbindingMessage").hide();
				return false;
			}
			data = data["msg"];
			if(data.length == 0){
				$("#unbindCard").hide();
				$("#bindCard").show();
				$("#unbindingMessage").hide();
				return false;
			}
			if(data[0]["state"]=="unbinding" || data[0]["state"]=="bind"){
				$("#bankLogo").attr("src",path+"/images/bank/S_"+data[0]["bankNo"]+".png");//银行小logo
				$("#bankNum").text(data[0]["bankAccount"]).attr("bankNo",data[0]["bankNo"]);//银行卡号
			}
			if(data[0]["state"]=="bind"){
				$("#unbindCard").show();
				$("#bindCard").hide();
			}
			$("#unbindingMessage").hide();
			if(data[0]["state"]=="unbinding"){
				$("#unbindCard").hide();
				$("#bindCard").hide();
				$("#unbindingMessage").show();
			}
			
		},
		error: function(request){
			console.log("获取已绑定银行信息异常");
		}
	});
}*/

//查询已经绑定的银行卡信息
function getUserBank() {
	$.ajax({
		url : path + "/sina/bankcard/SelectBankCard.html",
		type : "post",
		dataType : "json",
		success : function(data) {
			if (!data) {
				return false;
			}
			var bArr = [], bStr = '', l;
			l = data.length;
			userBankData = data;
			var reg = /^(\d{4})\d+(\d{4})$/;
			for(var i=0;i<l;i++){
				
				var str = data[i]["bank_account_no"];
				
				str = str.replace(reg, "$1****$2");
				bArr.push('<li>');
				bArr.push('<div class="yh_img"><img src='+path+'/images/bank/S_'+data[i]["bank_code"]+'.png /></div>');
				bArr.push('<p class="yh_num">'+str+'</p>');
				bArr.push('<div class="yh_but">');
				bArr.push('<a href="javascript:void(0);" indexId='+i+' deleteId='+data[i]["card_id"]+' onclick="deleteBankEvent(event);" style="width:100%;">删除</a>');
				bArr.push('</div>');
				bArr.push('</li>');
			}
			if(l == 0){ //如果没有绑定银行卡，则 添加按钮
				bArr.push('<li style="border:none;width:500px;color:red;">暂无银行卡信息</li>')
			}
			bStr = bArr.join("");
			$("#bank_y").html(bStr);
		},
		error : function(request) {
			console.log("获取已绑定银行信息异常");
		}
	});
}

var deleteIndex = null;
function deleteBankEvent(event){
	//可以写一个  兼容的意思
	var obj = event.srcElement || event.target;
	var deleteId = $(obj).attr("deleteId");
	AlertDialog.confirm(deleteBank, null, "您确定要删除吗？", "确定", "取消", deleteId);
	$("#deValiCode").hide();
}

function deleteBank(id){
	$.ajax({
		url: path + "/sina/bankcard/deleteUserBankCard.html",
		type: "post",
		dataType: "json",
		data: {
			"cardId": id
		},
		success: function(data){
			
			if(data["success"]){
//				deletemesg["cardId"] = id;
//				deletemesg["ticket"] = data["ticket"];
		//		showDeValiCode();
				AlertDialog.tip("删除成功");
				window.setTimeout(function(){
					window.location.reload();
				},3000)
			}else{
				AlertDialog.tip(data["msg"])
			}
			
//			if(data["success"]){
//				AlertDialog.tip("删除银行卡成功");
//				$("a[deleteId="+id+"]").parent().parent().remove();
//			}else{
//				AlertDialog.tip(data["msg"]);
//			}
		},
		error: function(request){
			console.log("删除银行卡异常");
		}
	});
}


//查询用户可用余额值
function getUserdAmt(){
	$.ajax({
		url: path + "/bill/getUserBalance.html",
		type: "post",
		dataType: "json",
		success: function(data){
			if(!data["success"]){
				return false;
			}
			$("#canUserdAmt").text(data["msg"].toFixed(2));
		},
		error: function(request){
			conosle.log("获取用户可用余额值异常");
		}
	});
}
//取现金额输入框事件
function withdrawInput(){
	//应该输入数字并且小于等于 可用金额
	var val = $("#amtInput").val();
	if(!val){
		AlertDialog.show("请输入提现金额","amtInput",10,30);
		return false;
	}
	if(Number(val) == 0){
		AlertDialog.show("提现金额不能为0","amtInput",10,100);
		return false;
	}
	if(Number(val) < 0){
		AlertDialog.show("提现金额不能为负数","amtInput",10,30);
		return;
	}
	AlertDialog.hide();
	//展示手续费
	$.ajax({
		url: path + "/sina/withdraw/getWithDrawFee.html",
		type: "post",
		dataType: "json",
		data: {
			"withdrawAmt":  $("#amtInput").val()
		},
		success: function(data){
			if(!data["success"]){
				$("#poundage").text(0);
				return false;
			}
			$("#poundage").text(data["msg"]);
		},
		error: function(request){
			console.log("获取手续费异常");
		}
	});
	return true;
	if(Number($("#canUserdAmt").text())-$("#poundage") <=0){
		AlertDialog.show("可用余额不足以支付手续费 无法提现","amtInput",10,30);
	}else if(isNaN(val) || Number(val)+$("#poundage")> Number($("#canUserdAmt").text())){
		var maxInput = Number($("#canUserdAmt").text()) -$("#poundage");
		AlertDialog.show("输入金额 不能大于"+maxInput,"amtInput",10,30);
		$("#amtInput").val("");
		return false;
	}else if(!isNaN(val) && Number(val) <= Number($("#canUserdAmt").text())){
		AlertDialog.hide();
		return true;
	}
}
//获取手机验证码
function getPhoneCode(){
	/*if(!$("#bankNum").text()){
		AlertDialog.tip("请绑定银行卡");
		return false;
	}*/
	if(withdrawInput()){
		$.ajax({
			url: path + "/verifycode/sendUserVerifyCode.html",
			type: "post",
			dataType: "json",
			data: {"codeType": "withdraw_remind"},
			success: function(data){
				if(!data["success"]){
					$("#getCodeBtn").parent().children(".inputf").text(data["msg"]).show();
				}else{
					$("#getCodeBtn").unbind("click").css({"color":"#434343","cursor":"default"}).text("60 秒后可重发");
					countDown(60, "getCodeBtn", overFn);
				}
			},
			error: function(request){
				conosle.log("获取用户可用余额值异常");
			}
		});
	}
}
function overFn(){
	$("#getCodeBtn").text("获取验证码").css({"cursor":"pointer"});
	$("#getCodeBtn").click(getPhoneCode);
}
//取现
function withDraw(){
//	if(!$("#bankNum").text()){
//		AlertDialog.tip("请绑定银行卡");
//		return false;
//	}
	if(!withdrawInput()){
		return false;
	}
	if($("#amtInput").val() && !isNaN($("#amtInput").val()) && Number($("#amtInput").val()) <= Number($("#canUserdAmt").text())){
		if(Number($("#canUserdAmt").html()) < Number($('#amtInput').val())+Number($("#poundage").text())){
			AlertDialog.tip("提现金额应小于等于可用余额减去提现手续费");
			return false;
		}
		
		if($("#verifyCode").val()){
			
			
			//提现前验证
			$("#withdrawBtn").unbind("click").css("background", "#ccc").text("提现中...");
			$.ajax({
				url: path + "/sina/withdraw/checkCreateWithDraw.html",
				type: "post",
				dataType: "json",
				data: {
					"amt": $("#amtInput").val(),
					"verifyCode": $("#verifyCode").val()
				},
				success: function(data){
					if(!data["success"]){
						AlertDialog.tip(data["msg"]);
						$("#withdrawBtn").click(withDraw).css("background", "#51befb").text("提现");
						return false;
					}
//					$("#form_bankCardId").val(Number($("#bankNum").text()));
//					$("#form_withdrawWay").val($("#bankNum").attr("bankNo"));
					$("#form_amt").val($("#amtInput").val());
					$("#withdrawFormBtn").click();
					
				},
				error: function(request){
					$("#withdrawBtn").click(userWithdraw).css("background", "#51befb").text("提现");
					console.log("提现验证异常");
				}
			});
			//提现前验证
			/*$.ajax({
				url: path + "/withdraw/checkWithdraw.html",
				type: "post",
				dataType: "json",
				async: false,
				data: {
					"amt": $("#amtInput").val(),
					"fee": "2",
					"verifyCode": $("#verifyCode").val()
				},
				success: function(data){
					if(data["success"]){
						$("#withdrawBtn").css("background", "#ccc").unbind("click");
						//$('#withdrawForm').submit();
						 $("#withBtn").click();
					}else{
						if(data["msg"]){
							AlertDialog.tip(data["msg"]);
						}else{
							AlertDialog.tip("取现异常，请联系客服");
						}
					}
				},
				error: function(request){
					console.log("获取提现信息异常");
				}
			});*/
		}else{
			AlertDialog.tip("请输入验证码");
			return false;
		}
	}else{
		AlertDialog.tip("请输入小于或等于可用余额的数字");
		return false;
	}
}
//绑定银行卡前验证

function bindCard(){
	$.ajax({
		url: path + "/third/bankcard/checkBeforeBindBank.html",
		type: "post",
		dataType: "json",
		success: function(data){
			if(data["success"]){
				//是否实名认证
				if(isAuth == "1"){
					$("#bindCard").attr("href", path + "/yeepay/bankcard/createBankCard.html?" + new Date().getTime());
				}else{
					$("#bindCard").click(function(){
						AlertDialog.confirm(delGood,null,"未实名认证，是否实名认证！","确定","取消");
					});
					function delGood(){
						location.href = path+"/common/realBindUser.html";
					}
				}
			}else{
				$("#bindCard").click(function(){
					AlertDialog.tip(data["msg"]);
				});
			}
		},
		error: function(request){
			console.log("获取用户可用余额值异常");
		}
	});
	
}