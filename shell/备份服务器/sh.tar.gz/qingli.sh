#!/bin/bash
sed  -i '/没有检测到文件/'d /home/lingbugsit/.sh/logs/update00.logs 
sed  -i '/还好没有rar文件/'d /home/lingbugsit/.sh/logs/update00.logs
