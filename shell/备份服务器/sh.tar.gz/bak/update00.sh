#!/bin/bash
cd /home/lingbugsit/
find ./* -name "*.*" -print|grep -v ".zip"|grep -v ".sh" > /tmp/linshi2
if [ -s /tmp/linshi2 ]
   then
        echo ssssssssssssssss
else
	echo "没有检测到文件`date`"
        exit
fi

wjlj=`cat /tmp/linshi2`
for i in $wjlj
    do
	xmname=`echo $i|cut -d "/" -f 2`
	qhname=`echo $i|cut -d "/" -f 3`
	wjname=`echo $i|sed 's#/.*/#/#'|cut -d "/" -f 2`
	csxmname=`ssh root@ceshi.lingbug "ls /home/tomcat/$xmname/webapps/|grep web|grep -v .zip|cut -d '-' -f 1"`
	cswjlj=`ssh ceshi.lingbug "find /home/tomcat/$xmname/webapps/$csxmname-$qhname/* -name '$wjname'"`
	echo "正在上传文件 $xmname"
		#判断文件唯一性
		
	scp $i ceshi.lingbug:$cswjlj &> /home/lingbug/.sh/update00.sh
	rm -rf $i
    done
sun=`cat /tmp/linshi2 |grep -v .js|grep -v .css|grep -v .jsp|grep -v /image|cut -d "/" -f 2|sort -u`
if [ -z $sun ]
   then
	echo "没有检测到静态文件"
	exit
else
	echo "检测到文件有改动，执行重启"
fi
for i in $sun
    do
	echo "关闭 $i 项目"
	ssh root@ceshi.lingbug "/home/tomcat/$i/bin/shutdown.sh"
	echo "启动 $i 项目"
	sleep 5
	ssh root@ceshi.lingbug "/home/tomcat/$i/bin/one-startup.sh"
    done
