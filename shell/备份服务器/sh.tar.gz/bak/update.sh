#!/bin/bash
#切至目标工作目录
cd /home/lingbugsit/
#执行单个文件更新脚本
#bash /home/lingbugsit/.sh/update02.sh
#遍历文件夹中是否有压缩包上传
find ./* -name "*.zip" > /tmp/linshi
if [ -s /tmp/linshi ]
   then
        echo ssssssssssssssss
else
	echo "没有检测到文件`date`"
        exit
fi

#删除上次更新残余文件
\rm -rf /tmp/jiaoben/*


#停止定时任务，防止更新过程中再次触发脚本
/sbin/service crond stop

#定义反馈文件名
a="检测压缩包完整性。。。"
aa="压缩包不完整-稍后再试。。。"
b="正在打包上传至测试服务器。。。"
ba="关闭tomcat备份文件。。。"
c="正在重启tomcat中。。。"
d="启动成功。。。"
da="啊哦,更新失败-请联系孙国帅..."


#开始更新
lujing=`cat /tmp/linshi`
for i in $lujing
    do
        xmname=`echo $i|cut -d "/" -f 2`
        qhname=`echo $i|cut -d "/" -f 3`
	ysname=`echo $i|cut -d "/" -f 4`
	xmbdlj=/home/lingbugsit/$xmname/$qhname/

	#删除上次更新残余文件
	\rm -rf /tmp/jiaoben/*
	
	cd $xmbdlj && \rm -rf $a $aa $b $ba $c $d $da
	touch $xmbdlj/$a


	#判断压缩包的完好性
	cd /home/lingbugsit/
	sun=5
	unzip -tq $i || sleep 3
	unzip -tq $i || sleep 8
	unzip -tq $i || sun=3
		if [ 3 -eq $sun ]
		    then
			mv $xmbdlj/$a $xmbdlj/$aa
			/sbin/service crond start
			exit
		else
			echo sunsunsunusnusnus
		fi

        mv $i /tmp/jiaoben/ && cd /tmp/jiaoben/
        unzip -q $ysname
	wjname=`ls | grep -v .zip`

	mv $xmbdlj/$a $xmbdlj/$b

	cd $wjname
	\rm -rf WEB-INF/classes/config/config.properties  WEB-INF/classes/huifubao/*  WEB-INF/classes/fundpool/*  WEB-INF/classes/huichao/*  WEB-INF/classes/yeepay/*  WEB-INF/classes/sina/*  js/common/ueditor/jsp/* WEB-INF/classes/SIMSUN.TTC  WEB-INF/lib/*
	cd .. && \rm -rf $ysname && zip -rmq $ysname $wjname
	scp $ysname ceshi.lingbug:/home/.tomcat/.zip/$qhname/
	csxmname=`ssh root@ceshi.lingbug "ls /home/tomcat/$xmname/webapps/|grep web|grep -v .zip|cut -d '-' -f 1"`

	ssh root@ceshi.lingbug "/home/tomcat/$xmname/bin/shutdown.sh"
	#备份原始文件
	mv $xmbdlj/$b $xmbdlj/$ba
	ssh root@ceshi.lingbug "\rm -rf  /home/tomcat/$xmname/webapps/*.zip"
	ssh root@ceshi.lingbug "cd /home/tomcat/$xmname/bak/ && tar zcf beifen.tar.gz ../webapps/* "

	#覆盖更新文件
	ssh root@ceshi.lingbug "unzip -d /home/.tomcat/.zip/$qhname -oq /home/.tomcat/.zip/$qhname/$ysname"
	ssh root@ceshi.lingbug "echo `date` > /home/.tomcat/.zip/$qhname/$wjname/update"
	mv $xmbdlj/$ba $xmbdlj/$c
	ssh root@ceshi.lingbug "\cp -r /home/.tomcat/.zip/$qhname/$wjname/* /home/tomcat/$xmname/webapps/$csxmname-$qhname/"
	ssh root@ceshi.lingbug "/home/tomcat/$xmname/bin/one-startup.sh"
	sleep 5
	ssh root@ceshi.lingbug "\rm -rf /home/.tomcat/.zip/$qhname/*"
		#判断tomcat是否启动成功
		xmdk=`echo $xmname|cut -d "-" -f 2`
		pdwj=`curl -o /dev/null --retry 3 --retry-max-time 8 -s -w %{http_code} ceshi.lingbug:$xmdk/$csxmname-$qhname/`
		if [ 200 -eq $pdwj ]
		    then
			mv $xmbdlj/$c $xmbdlj/$d
		        echo "更新完成。。。"
		elif [ 302 -eq $pdwj ]
		    then
			mv $xmbdlj/$c $xmbdlj/$d
		        echo "更新完成。。。"
		else
			mv $xmbdlj/$c $xmbdlj/$da
		    echo "启动失败-请联系。。。"
		fi	
echo "-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------" >> /home/lingbugsit/.sh/logs/update.logs
    done
#启动定时任务，定时检测
/sbin/service crond start





#name=`ls | cut -d "." -f 1`
#new=`date +%M`
#unzip $name.zip
#cd `ls |grep -v .zip`
#\rm -rf WEB-INF/classes/config/config.properties  WEB-INF/classes/huifubao/*  WEB-INF/classes/fundpool/*  WEB-INF/classes/huichao/*  WEB-INF/classes/yeepay/*  WEB-INF/classes/sina/*  js/common/common.js  js/common/ueditor/jsp/* WEB-INF/classes/SIMSUN.TTC  WEB-INF/lib/*
#cd ..
#$newname=$name-$new.zip
#zip -r $newname `ls |grep -v .zip`
#cp $newname /home/tomcat-134/zip/
#ssh root@ceshi.lingbug "unzip -d /home/.tomcat/zip /home/.tomcat/zip/$name"
#ssh root@ceshi.lingbug "unzip -d /home/.tomcat/zip /home/.tomcat/zip/taida-admin-43.zip"
